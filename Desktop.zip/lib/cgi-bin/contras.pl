#!/usr/bin/perl

use strict;
use warnings;

use CGI;
use CGI::Session;
use DBI;
use Linux::Usermod;

my $db = 'main';
my $hostname = 'localhost';
my $user = 'root_user';
my $password = 'root_password';

my $access_key = "DBI:MariaDB:database=$db;host=$hostname";
my $db_handler = DBI->connect($access_key, $user, $password,{ RaiseError => 1, PrintError=> 0 });
my ($mail, $ERR)=Email::Send::SMTP::Gmail->new( -smtp=>'smtp.gmail.com', -login=>'correopostfixadsis@gmail.com', -pass=>'Administracion28');

print "session error: $ERR" unless ($mail!=-1);

my $q = new CGI;

my $session = CGI::Session->load() or die CGI::Session->errstr();
if($session->is_expired || $session->is_empty){
        print $q->redirect('/var/www/html/index.html');
}

my $datos = $db_handler->prepare ('SELECT * FROM main.users');
$datos->execute()

if ($q->param("submit")){
	submit();
}
sub submit{
if(datos_validos){

	if((my $temp_user = $datos->fetchrow_hashref('email')) == q->param{'email'}) {

		my $LinuxUser = Linux::Usermod->del($temp_user->{'username'});
		Linux::Usermod->add($temp_user->{'username'}, $q->param{'password'}, undef, undef, undef, "/home/".$temp_user->{'username'},"/bin/bash");
      		my $LinuxUser = Linux::usermod->new($temp_user->{'username'});
		chown $LinuxUser->get(2), $LinuxUser->get(3), "/home/".$temp_user->{'username'};
		`/usr/sbin/setquota -u $temp_user->{'username'} 50M 80M 0 0 / `;
		$mail->send(-to=>$temp_user->{'email'}, -subject=>'Cambio Contraseña', -body=>'Contraseña cambiada', -contenttype=>'text/html');	
		print $q->redirect("/cgi-bin/mostrarPerfil.pl");  
	}
}
}
$mail->bye;

sub datos_validos{

	my $email = $q->param("email");
	my $password = $q->param("password");
	
        my $ERR_MSG = "";

        $ERR_MSG .= "Please enter an email<br>" if(!$q->param("email"));
	$ERR_MSG .= "Please enter an password<br>" if(!$q->param("password"));

        if($ERR_MSG){
                return 0;
        } else {
                return 1;
        }
}