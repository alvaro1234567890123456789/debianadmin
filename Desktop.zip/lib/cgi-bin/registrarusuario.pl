#!user/bin/perl


use CGI;
use DBI;
use strict;
use warnings;

my $db = 'main';
my $hostanme = 'localhost';
my $user = 'root_user';
my $password = 'root_password';

my $access_key = "DBI:MariaDB:database=$db;
			host = $hostname";
my $db_handler = DBI->conect($access_key, $user, $password,{RaiseError =>1, PrintError=>0});

my $q = new CGI;

#Comprobamos si los datos introducidos son correctos

if($q->param("submit")){

	submit();
}

sub submit{

	if(datos_validos()){

		$db_handler->do('INSERT INTO pending_users(username, firstname, surname, email, password, address, phone, tipo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', undef, $q->param("firstname"), $q->param("surname"), $q->param("email"), $q->param("password"), $q->param("address"), $q->param("phone"),  $q->param("tipo"));
		print $q->redirect(-url=>'/login.html');
	}
}

sub datos_validos{

	my $username = $q->param("username");
	my $firstname = $q->param("firstname");
	my $surname = $q->param("surname");
	my $address = $q->param("address");
	my $phone = $q->param("phone");
	my $email = $q->param("email");
	my $password = $q->param("password");
	my $tipo = $q->param("tipo");
	my $ERR_MSG = "";

	$ERR_MSG .= "Introduzca nombre de usuario<br>"
		
		if(!$username);
	
	$ERR_MSG .= "Introduzca firstname<br>"
		
		if(!$firstname);

	$ERR_MSG .= "Introduzca surname<br>"
		
		if(!$surname);

	$ERR_MSG .= "Introduzca dirección<br>"
		
		if(!$address);

	$ERR_MSG .= "Introduzca teléfono<br>"
		
		if(!$phone);

	$ERR_MSG .= "Introduzca email<br>"
		
		if(!$email);

	$ERR_MSG .= "Introduzca contraseña<br>"
		
		if(!$password);


	$ERR_MSG .= "Introduzca tipo de usuario<br>"
		
		if(!$password);
}

# Si hay error redirige a la página principal

if($ERR_MSG){

	return 0;
}
else{

	return 1;
}
}
