#!/usr/bin/perl

use strcit;
use warings;

use DBI;
use CGI;
use CGI::Sesion;
use Authen::Simple::PAM;
use Sys::Syslog;

openlog("LOGIN", undef, "local");

my $pam = Authen::Simple:PAM->(service=>'login');

my $db = 'main';
my $hostname = 'localhost';
my $user = 'root_user';
my $password = 'root_password';

my $acces_key = "DBI:MariaDB:database=$db; host = $hostname";
my $db_handler = DBI->connect($access_key,$user, $password, {RaiseError =>1, PrintError =>0});

my $q = CGI->new;

#print $q->header

if($q -> param ("submit")){

	submit();
}

sub submit{

	if($pam -> authenticate($q -> param("username"), $q -> param("password"))){

		syslog("info", "Sesión Iniciada:".$q->param("username"));
		my $temp_users = $db_handler->prepare('SELECT * FROM users WHERE username  = ?');
		$tem_users ->execute($q ->param("username"));
		
		if (my $u = $temp_users->fetchrow-hashref()){
	
			my $sesion = CGI::Session->new;
			print $session->header();
			$session->param ('id', $su->{'id'};
			print '< meta http -equiv = "refresh" content = "0;URL = mostrarPerfil.pl">';
		}
		
	} else {
		
		syslog ("info", "Sesión Fallida:".$q -> param ("username"));
		print $q -> redirect('/login.html');
	}
}
