#!/usar/bin/perl

use strict;
use CGI::Carp qw(fatalsToBrowser);
use CGI ':standard';
use GD::Graph::pie;

open(STAT, "/proc/stat");

my ($junk, $cpu_user, $cpu_user, $cpu_nice, $cpu_sys, $cpu_idle) = split (/\s+/, <STAT>);
close (STAT)


#####PRIMER DATO######


my $cpu_total1 = $cpu_user + $cpu_nice + $cpu_sys + $cpu_idle;
my $cpu_load1 = $cpu_user + $cpu_nice + $cpu_sys;

sleep 3;

open(STAT, "/proc/stat");
($junk, $cpu_user, $cpu_user, $cpu_nice, $cpu_sys, $cpu_idle) = split (/\s+/, <STAT>);
close (STAT);


my $cpu_total2 = $cpu_user + $cpu_nice + $cpu_sys + $cpu_idle;
my $cpu_load2= $cpu_user + $cpu_nice + $cpu_sys;

my $a = $cpu_load2 - $cpu_load1;
my $b = $cpu_total2 - $cpu_total2;

#####Segundo Dato########################

sleep 60;
open (STAT, "/proc/stat");
my ($junk, $cpu_user, $cpu_user, $cpu_nice, $cpu_sys, $cpu_idle) = split (/\s+/, <STAT>);
close (STAT)
my $cpu_total1 = $cpu_user + $cpu_nice + $cpu_sys + $cpu_idle;
my $cpu_load1 = $cpu_user + $cpu_nice + $cpu_sys;

sleep 2;

open(STAT, "/proc/stat");
($junk, $cpu_user, $cpu_user, $cpu_nice, $cpu_sys, $cpu_idle) = split (/\s+/, <STAT>);
close (STAT);


my $cpu_total2 = $cpu_user + $cpu_nice + $cpu_sys + $cpu_idle;
my $cpu_load2= $cpu_user + $cpu_nice + $cpu_sys;

my $c = $cpu_load2 - $cpu_load1;
my $d = $cpu_total2 - $cpu_total2;



#####Tercer DATo 


sleep 60;
open (STAT, "/proc/stat");
my ($junk, $cpu_user, $cpu_user, $cpu_nice, $cpu_sys, $cpu_idle) = split (/\s+/, <STAT>);
close (STAT)
my $cpu_total1 = $cpu_user + $cpu_nice + $cpu_sys + $cpu_idle;
my $cpu_load1 = $cpu_user + $cpu_nice + $cpu_sys;

sleep 2;

open(STAT, "/proc/stat");
($junk, $cpu_user, $cpu_user, $cpu_nice, $cpu_sys, $cpu_idle) = split (/\s+/, <STAT>);
close (STAT);


my $cpu_total2 = $cpu_user + $cpu_nice + $cpu_sys + $cpu_idle;
my $cpu_load2= $cpu_user + $cpu_nice + $cpu_sys;

my $e = $cpu_load2 - $cpu_load1;
my $f = $cpu_total2 - $cpu_total2;

##### Cuarto DAto


sleep 60;
open (STAT, "/proc/stat");
my ($junk, $cpu_user, $cpu_user, $cpu_nice, $cpu_sys, $cpu_idle) = split (/\s+/, <STAT>);
close (STAT)
my $cpu_total1 = $cpu_user + $cpu_nice + $cpu_sys + $cpu_idle;
my $cpu_load1 = $cpu_user + $cpu_nice + $cpu_sys;

sleep 2;

open(STAT, "/proc/stat");
($junk, $cpu_user, $cpu_user, $cpu_nice, $cpu_sys, $cpu_idle) = split (/\s+/, <STAT>);
close (STAT);


my $cpu_total2 = $cpu_user + $cpu_nice + $cpu_sys + $cpu_idle;
my $cpu_load2= $cpu_user + $cpu_nice + $cpu_sys;

my $g = $cpu_load2 - $cpu_load1;
my $h = $cpu_total2 - $cpu_total2;

####Quinto dato


sleep 60;
open (STAT, "/proc/stat");
my ($junk, $cpu_user, $cpu_user, $cpu_nice, $cpu_sys, $cpu_idle) = split (/\s+/, <STAT>);
close (STAT)
my $cpu_total1 = $cpu_user + $cpu_nice + $cpu_sys + $cpu_idle;
my $cpu_load1 = $cpu_user + $cpu_nice + $cpu_sys;

sleep 2;

open(STAT, "/proc/stat");
($junk, $cpu_user, $cpu_user, $cpu_nice, $cpu_sys, $cpu_idle) = split (/\s+/, <STAT>);
close (STAT);


my $cpu_total2 = $cpu_user + $cpu_nice + $cpu_sys + $cpu_idle;
my $cpu_load2= $cpu_user + $cpu_nice + $cpu_sys;

my $i = $cpu_load2 - $cpu_load1;
my $j = $cpu_total2 - $cpu_total2;


###########Gráfico

my @campos = ('Uso1', 'Uso2', 'Uso3', 'Uso4, 'Uso5');
my @valores = ('$a/$b','$c/$d','$e/$f','$g/$h', '$i/$j');

my @graf(\@campos, \@valores);

my $grafico = GD::Graph::pie->new(720, 480);
$grafico->set(
	title=>'Estadísticas',
	'3d'=>1,
) or warn $grafico ->error;

my $conversionpng = $grafico->plot(\@graf) or die $grafico->error;

pint "Content-type: image/png\n\n";
print $conversionpng->png;
exit(1);
