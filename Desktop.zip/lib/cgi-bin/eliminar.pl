#!/usr/bin/perl

use strict;
use warnings;

use CGI;
use Linux::usermod;
use Authen::Simple::PAM;
use CGI::Session;
use DBI;

my $pam = Authen::Simple::PAM->new(service=>'login');

my $db = 'main';
my $hostname = 'localhost';
my $user = 'user_root';
my $password = 'root_password';

my $access_key = "DBI:MariaDB:database = $db; host = $hostname")
my $db_handler = DBI->connect($access_key, $user, $password, {RaiseError=>1, PrintError=>0});

my $q = new CGI;

my $session = CGI::Session->load() or die CGI::Session->errstr();
if($session->is_expired || $session->is_empty){

	print $q->redirect('/var/www/html/index.html');
}

my $temp_user = $db_handler->prepare('SELECT * FROM users WHERE id = ?');
$temp_users->execute($session->param('id'));
my $u = $temp_users->fetchrow_hashref();

if(!($q->param("checkPassword") eq '')){

	if($pam->authenticate($u->{'username'}, $q->param("checkPassword"))){

		Linux::usermod->del($u->{'username'});
			$db_handler->do('DELETE FROM users WHERE id = ?', undef, $session->param('id'));
		$session->delete();
		$session->flush();
		print $q->redirect("/index.html");
	}

	else{

		print $q->redirect("/cgi-bin/perfil.pl");
	}
}
else{

	print $q->redirect("/cgi-bin/perfil.pl");
}
