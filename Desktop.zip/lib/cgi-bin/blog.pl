#!/usr/bin/perl


use strict;
use warnings;

use CGI;
use DBI;
use CGI::Session;
use File::Copy::Recursive qw( fcopy rcopy dircopy fmove rmove dirmove);

my $db = 'main';
my $hostname = 'localhost';
my $user =  'root_user';
my $password = 'root_password';

my $CGI = CGI->new;

my $access_key = "DBI:MariaDB:database = $db; $host = $hostname";
my $db_handler = DBI->connect($access_key, $user, $password, {RaiseError=>1, PintError=>0});


my $session = CGI::Session->load() or die CGI::Session->errstr();

if($session->is_expired || $session->is_empty){

	print $q->redirect('/var/www/html/index.html');
}

my $temp_users = $db_handler->prepare ('SELECT * FROM users WHERE if = ?');
$temp_users->execute($session->param('id'));
my $u = $temp_users->fetchrow_hashref();

my $templateBlog = "/var/www/blogTemplate";
my $carpetaUsuario = "/var/www/html/blog/".$u->{'username');

if(mkdir $carpetaUsuario){

	rcopy($templateBlog, $carpetaUsuario) or die "Error al realizar la copia del blog";
	print $q->redirect("/blog/".$su->{username});
}
else{

	print $q->redirect("/blog/".$su->{'username'});
}
