#!/bin/bash

rsync -raz /home /root/homecopia/
