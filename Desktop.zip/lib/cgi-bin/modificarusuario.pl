#!/usr/bin/perl

use strict;
use warnings;

use CGI;
use CGI::Session;
use DBI;

my $db = 'main';
my $hostname = 'localhost';
my $user = 'root_user';
my $password = 'root_password';

my $acces_key = "DBI::MariaDB::database=$db; host = $hostname";
my $db_handler = DBI->connect($access_key, $user, $password, {RaiseError=> 1, PrintError=>0});

my $q = new CGI;

my $session = CGI::Session->load() or die CGI::Session->errstr();

if($session->is_expired || $session->is_empty){

	print $q->redirect('/var/www/html/index.html');
}

my $temp_users = $db_handler->prepare('SELECT * FROM users WHERE id = ?');
$temp_users->execute($session->param('id');
my $u = $temp_users->fetchrow_hashref();

if(datos_validos()){

	if(!($q->param("firstname") eq $u->u{'firstname'}) && !($q->param("firstname") eq '')){

		$db_handler->do('UPDATE users SET firstname = ? WHERE id = ?', undef, $q->param("firstname"), $session->param('id'));
	}

	
	if(!($q->param("surname") eq $u->u{'surname'}) && !($q->param("surname") eq '')){

		$db_handler->do('UPDATE users SET surname = ? WHERE id = ?', undef, $q->param("surname"), $session->param('id'));
	}


	if(!($q->param("email") eq $u->u{'email'}) && !($q->param("email") eq '')){

		$db_handler->do('UPDATE users SET email = ? WHERE id = ?', undef, $q->param("email"), $session->param('id'));
	}


	if(!($q->param("address") eq $u->u{'address'}) && !($q->param("address") eq '')){

		$db_handler->do('UPDATE users SET address = ? WHERE id = ?', undef, $q->param("address"), $session->param('id'));
	}


	if(!($q->param("phone") eq $u->u{'phone'}) && !($q->param("phone") eq '')){

		$db_handler->do('UPDATE users SET phone = ? WHERE id = ?', undef, $q->param("phone"), $session->param('id'));
	}

	print $q->redirect("/cgi-bin/perfil.pl");
}

sub datos_validos{

	my $ERR_MSG = "";
	
	$ERR_MSG .= "Por favor introduzca el nombre<br>"

	if(!$q->param("firstname"));

	$ERR_MSG .= "Por favor introduzca el apellido<br>"

	if(!$q->param("surname"));

	$ERR_MSG .= "Por favor introduzca el email<br>"

	if(!$q->param("email"));

	$ERR_MSG .= "Por favor introduzca el direcció<br>"

	if(!$q->param("address"));

	$ERR_MSG .= "Por favor introduzca el teléfono<br>"

	if(!$q->param("phone"));

	if($ERR_MSG){

		return 0;
	}else{

		return 1;
	}
}
