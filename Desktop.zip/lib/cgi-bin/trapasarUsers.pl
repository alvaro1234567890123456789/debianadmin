!#usr/bin/perl

use strict;
use warnings;

use Linux::usermod
use Email::Send::SMTP::Gmail;
use DBI;

my $db = 'main';
my $hostname = 'localholst';
my $user = 'root_user';
my $password = 'root_password';

my $access_key = "DBI:MariaDB:database=$db; 
		host = $hostname";
my $db_handler = DBI->conect($access_key, $user, $password,{RaiseError =>1, PrintError=>0});
my ($mail, $ERR) = Email::Send::SMPT::Gmail->new(-smtp=>'smtp.gmail.com', -login=>'correopostfixadsis@gmail.com', -pass=>'Admistracion28');

print "sesion error: $ERR" unless($email!=-1);

 my $data = $db_handler->prepare('SELECT * FROM main.Notusers');
$data->execute();

while(my $temp_user = $data->fechtrrow_hashref()){
	
	Linux::usermod->add($temp_user->{'username'},$temp_user->{'password'},undef, undef, undef, undef, "/home/".$temp_user->{'username'}, "/bin/bash");
	mkdir "/home".$temp_user->{'username'};

	my $LinuxUser = Linux::usermod->new($temp_user->{'username'});
	chown $LinuxUser->get(2), $linusUser->get(3), "/home/".$temp_user->{'username'};

	mkdir "/home/".$temp_user->{'username'}."/public_html/";

	`/usr/sbin/setquota -y $temp_user->{'username'} 0 80M 0 0/`; #Si queremos añadir una blanda se pone antes del 80 en el 0 que hay ahí
	if($temp_user->{'tipo'} == 0){
	
		mkdir "/home".$temp_user{'username'}."/public_html/apuntes/";
		chmod (0640, "/home/".$temp->user->{'username'}."/public_html/") or die "Couldn't change the permissions";
	}
	if($temp_user->{'tipo'} == 1){
	
		mkdir "/home".$temp_user{'username'}."/public_html/apuntes/";
		chmod (0660, "/home/".$temp->user->{'username'}."/public_html/") or die "Couldn't change the permissions";
	}

	$db_handler->do('INSERT INTO users(username, firstname, surname, email, address, phone, tipo) VALUES(?, ?, ?, ?, ?, ?, ?), undef, $temp_user->{'username'}, $temp_user->{'firstname'},  $temp_user->{'surname'},  $temp_user->{'email'},  $temp_user->{'address'},  $temp_user->{'phone'},$temp_user->{'username'});

	$email->send(-to=> $temp_user->{'email'}, -subject=>'Activación cuenta de usuario', -body=> 'La cuenta ha sido activada', -contenttype=>'text/html');
	$db_handler->do('DELETE FROM pending_users WHERE id = '?', undef, $temp_user->{'id'});
}

$mail->bye;
