#!/usr/bin/perl

use CGI;
use CGI::Session;
use strict;
use warnings;

my $q = new CGI;

my $session = CGI::Session->load() or die CGI::Session->errstr();
if($session->is_expired || $session->is_empty){

	print $q->redirect('/var/www/html/index.html');
}

$session->delete();
$session->flush();
print $q->redirect('/login.html');
